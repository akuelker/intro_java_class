public class WholeNum { 

    public static void main(String[] args) { 

        double num = Double.parseDouble(args[0]); 

        double hiNum = Math.ceil(num); 
        double loNum = Math.floor(num); 
        long roundNum = Math.round(num); 

        System.out.println("Original number: " + num); 
        System.out.println("Using ceil: " + hiNum); 
        System.out.println("Using floor: " + loNum); 
        System.out.println("Using round: " + roundNum); 
    } 
}
