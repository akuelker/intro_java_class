public class Casting { 

    public static void main(String[] args) {

        double num = 1.987;       
        int intNum = (int)num;
        int roundNum = (int)Math.round(num);     

        System.out.println("Cast without rounding: " + intNum); 
        System.out.println("Cast after rounding: " + roundNum); 
    } 
}
