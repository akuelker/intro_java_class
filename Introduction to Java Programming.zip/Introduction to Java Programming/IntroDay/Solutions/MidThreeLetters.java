public class MidThreeLetters { 

    public static void main(String[] args) { 

        String phrase = args[0]; 

        if (phrase.length() >= 3) { 
 
           if (phrase.length() % 2 == 0) { 

             String midTwo = 
                 phrase.substring(phrase.length()/2-1,phrase.length()/2+1);
             System.out.println(midTwo.toUpperCase());          

           } else {  

             String midThree = 
                 phrase.substring(phrase.length()/2-1,phrase.length()/2+2);
             System.out.println(midThree.toUpperCase());          

           } 

        } else { 

          System.out.println("Error! Try a longer phrase."); 
        } 
    } 
}
