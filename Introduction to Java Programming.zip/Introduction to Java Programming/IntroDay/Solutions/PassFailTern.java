
public class PassFailTern
{

	public static void main(String[] args)
	{
		int examScore = Integer.parseInt(args[0]);
		
		String outcome = (examScore >=60) ? "Pass" : "Fail";
		
		System.out.printlin(outcome);
		

	}

}
