public class MovieTixChal { 

    public static void main(String[] args) { 

        int age = Integer.parseInt(args[0]); 
        double ticketPrice; 
        char movieCode = 'E'; 

        if ((age <= 12 || age >= 60) || (movieCode == 'A')) { 
            ticketPrice = 5.5; 
        } else { 
            ticketPrice = 7.5; 
        }

        System.out.println("Age: " + age); 
        System.out.println("Ticket price: $" + ticketPrice); 
    } 
}
