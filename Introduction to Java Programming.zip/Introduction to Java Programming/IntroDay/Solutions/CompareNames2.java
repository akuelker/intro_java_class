public class CompareNames2 { 

    public static void main(String[] args) { 

        String myName = "Sandy";
        String neighbor = args[0]; 
        int lengthDiff; 

        if (myName.length() > neighbor.length()) { 

           lengthDiff = myName.length() - neighbor.length();
           System.out.println(myName + " is " + lengthDiff +
                   " characters longer than " + neighbor);

        } else if (myName.length() < neighbor.length()) { 

           lengthDiff = neighbor.length() - myName.length();
           System.out.println(neighbor + " is " + lengthDiff +
                   " characters longer than " + myName);       

        } else { 

           System.out.println(myName + " and " + neighbor +
                   " are the same length");       
        }
    } 
}
