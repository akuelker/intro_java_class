public class WeeklyPay { 

    public static void main(String[] args) { 

        double weekHours = Double.parseDouble(args[0]); 
        String jobClass = "NON-EXEMPT"; 
        double hourRate = 10.; 
        double weekPay; 
        
        if (weekHours > 40 && jobClass == "NON-EXEMPT") {
            weekPay = (hourRate * 40) + 
                      ((weekHours - 40) * (hourRate * 1.5)); 
        }  else { 
            weekPay = hourRate * weekHours;
        }  

        System.out.println("Classification: " + jobClass); 
        System.out.println("Weekly hours: " + weekHours); 
        System.out.println("Weekly pay: $" + weekPay); 
    } 
}
