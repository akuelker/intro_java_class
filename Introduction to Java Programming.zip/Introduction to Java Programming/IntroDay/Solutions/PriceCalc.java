public class PriceCalc { 

    public static void main(String[] args) { 

        int salePrice = Integer.parseInt(args[0]); 
        final double TAX_RATE = .075;

        double taxAmt = salePrice * TAX_RATE; 
        double totalSale = salePrice + taxAmt; 

        System.out.println("Sale price: $" + salePrice); 
        System.out.println("Tax: $" + taxAmt); 
        System.out.println("Total sale: $" + totalSale); 
    } 
}
