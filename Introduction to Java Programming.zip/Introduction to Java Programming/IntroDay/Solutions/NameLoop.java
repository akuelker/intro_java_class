public class NameLoop { 

    public static void main(String[] args) { 

        String firstName = "Sandy"; 
 
        for (int i = 0; i < 5; i++) { 
            System.out.println(firstName); 
        }  
    } 
}
