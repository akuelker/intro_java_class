public class DiscPrice2 { 

    public static void main(String[] args) { 

        double origPrice = Double.parseDouble(args[0]); 
        double discPercent = .05; 
        double discPrice = (origPrice * (1 - discPercent)); 
        int roundedUpPrice = (int)Math.ceil(discPrice); 

        System.out.println("Discount price: $" + discPrice);
        System.out.println("Discount price rounded up: $" 
                + roundedUpPrice);        
    } 
} 
