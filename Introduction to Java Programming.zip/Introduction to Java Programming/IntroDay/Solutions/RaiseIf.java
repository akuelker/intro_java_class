public class RaiseIf { 

    public static void main(String[] args) {

        int evalScore = Integer.parseInt(args[0]); 
        double salary = 30000.;
        double raisePercent; 
      
        if (evalScore == 1) { 
            raisePercent = .05; 
        } else if (evalScore == 2) { 
            raisePercent = .03; 
        } else if (evalScore == 3) {
            raisePercent = .01; 
        } else { 
            raisePercent = 0; 
        } 

        salary = salary * (1 + raisePercent);

        System.out.println("Raise percent: " + 
                (raisePercent*100) + "%"); 

        System.out.println("New salary: $" + salary); 
    } 
}
