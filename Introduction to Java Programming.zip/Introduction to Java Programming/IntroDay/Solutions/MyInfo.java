/* This program displays my name and address on the screen. */

public class MyInfo { 

    public static void main(String[] args) { 

        System.out.println("Biff Arfuss");
        System.out.println("101 Main St.");
        System.out.println("St. Louis, MO 63001"); 
    } 
}
