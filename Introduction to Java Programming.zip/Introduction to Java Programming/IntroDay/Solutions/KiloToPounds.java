public class KiloToPounds { 

    public static void main(String[] args) { 
  
        int kg = 2; 
        double lb; 

        while (kg <= 20) { 
            lb = kg * 2.2; 
            System.out.println(kg + " kilograms\t" + lb + " pounds"); 
            kg += 2; 
        } 
    } 
}
