public class MyInfo2 { 

    public static void main(String[] args) { 

        String firstName = "Biff";
        String lastName = "Arfuss"; 

        System.out.println(firstName + " " + lastName);
        System.out.println("101 Main St.");
        System.out.println("St. Louis, MO 63001");      
    } 
}
