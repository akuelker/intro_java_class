public class Popcorn { 

    public static void main(String[] args) { 

        int numPeople = Integer.parseInt(args[0]); 

        if (numPeople > 0) { 

            String size; 
            double price; 

            if (numPeople == 1) { 

               size = "Large"; 
               price = 5.75; 

            } else if (numPeople == 2) { 

               size = "Grande"; 
               price = 7.95; 

            } else {
      
               size = "Jumbo"; 
               price = 9.95; 

            } 
 
            System.out.println("Number of people: " + numPeople); 
            System.out.println("Size: " + size); 
            System.out.println("Price: $" + price); 

        } else { 

            System.out.println("Error: You don't need popcorn!"); 
        }   
    }
}
