public class LastThreeLetters { 

    public static void main(String[] args) { 

        String phrase = args[0]; 

        if (phrase.length() >= 3) { 
  
            String lastThree = phrase.substring(phrase.length()-3);
            System.out.println(lastThree.toUpperCase());          

        } else { 

            System.out.println("Error! Try a longer phrase."); 
        } 
    } 
}
