public class RaiseSwitch { 

    public static void main(String[] args) {

        int evalScore = Integer.parseInt(args[0]); 
        double salary = 30000.;
        double raisePercent; 
      
        switch (evalScore) { 
        
            case 1: 
                raisePercent = .05; 
                break; 

            case 2:
                raisePercent = .03; 
                break; 

            case 3: 
                raisePercent = .01; 
                break; 

            default: 
                raisePercent = 0;                 
                break; 
        } 

        salary = salary * (1 + raisePercent);

        System.out.println("Raise percent: " + 
                (raisePercent*100) + "%"); 

        System.out.println("New salary: $" + salary); 
    } 
}
