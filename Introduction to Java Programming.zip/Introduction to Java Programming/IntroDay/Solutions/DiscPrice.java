public class DiscPrice { 

    public static void main(String[] args) { 

        int origPrice = Integer.parseInt(args[0]); 
        double discPercent = .05; 
        double discPrice = (origPrice * (1 - discPercent)); 
        long roundedPrice = Math.round(discPrice); 

        System.out.println("Discount price: $" + discPrice);
        System.out.println("Discount price to nearest dollar: $" 
                + roundedPrice);        
    } 
}
