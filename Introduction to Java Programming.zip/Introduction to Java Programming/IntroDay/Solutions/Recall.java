public class Recall { 

    public static void main(String[] args) {

        String[] defects = { "X100", "X770", "Y111", "Z440", "Z949", "A214" };
        String yourModel = args[0];
        
        for (int i = 0; i < defects.length; i++) { 

            if (yourModel.equals(defects[i])) { 

                 System.out.println("Your car has been recalled."); 
                 break;                                

            } 
        }
    }
}
