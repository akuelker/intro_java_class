public class CompareNames { 

    public static void main(String[] args) { 

        String myName = "Sandy";
        String neighbor = args[0]; 

        if (myName.compareToIgnoreCase(neighbor) < 0) { 
            System.out.println("My name precedes yours.");  
        } else if (myName.compareToIgnoreCase(neighbor) > 0) { 
            System.out.println("My name follows yours.");  
        } else { 
            System.out.println("Our names are the same.");  
        } 
    } 
}
