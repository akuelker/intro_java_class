public class TempConverter { 

    public static void main(String[] args) {

        double fahrTemp = Double.parseDouble(args[0]); 
        double celsTemp = 5. / 9. * (fahrTemp - 32); 
 
        System.out.println("Fahrenheit temp: " + fahrTemp); 
        System.out.println("Celsius temp: " + celsTemp); 
    } 
}
