public class Baseball { 

    public static void main(String[] args) { 

        int hitCode = Integer.parseInt(args[0]);
        String outcome; 
   
        switch (hitCode) { 

            case 1: 
                outcome = "Single"; 
                break; 
            case 2: 
                outcome = "Double"; 
                break; 
            case 3: 
                outcome = "Triple"; 
                break; 
            case 4: 
                outcome = "Home run"; 
                break; 
            default: 
                outcome = "You're out!"; 
                break; 
        } 

        System.out.println(outcome); 
    } 
}
