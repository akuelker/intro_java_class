public class Doubling { 

    public static void main(String[] args) { 

        int a = 2; 
        int counter = 0; 

        while (a < 32) { 
            a *= 2; 
            counter++; 
        } 

        System.out.println("Number of iterations: " + counter); 
    } 
}
