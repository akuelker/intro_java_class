public class GroceryBudget { 

    public static void main(String[] args) { 

        double monthTotal = 0; 
        int budget = 200; 

        for (int i = 0; i < args.length; i++) { 
            monthTotal += Double.parseDouble(args[i]);             
        } 

        System.out.println("You spent $" + monthTotal + " this month."); 

        if (budget >= monthTotal) { 
            System.out.println("Good job! You stuck to the budget!");         
        } else { 
            System.out.println("You exceeded your budget by $"
                    + (monthTotal - budget)); 
        } 
    } 
}
