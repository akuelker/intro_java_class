public class Vacation { 

    public static void main(String[] args) { 

        int years = Integer.parseInt(args[0]); 
        int vacationDays;         

        if (years < 1) { 
            vacationDays = 5;     
        } else if (years <= 5) { 
            vacationDays = 10;     
        } else if (years <= 10) { 
            vacationDays = 15;     
        } else { 
            vacationDays = 20;     
        } 

        System.out.println("You get " + vacationDays + 
                " days, based on " + years + " years of service."); 
    } 
}
