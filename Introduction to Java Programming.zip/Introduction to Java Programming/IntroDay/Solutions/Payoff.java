public class Payoff { 

    public static void main(String[] args) { 

        int balance = Integer.parseInt(args[0]); 
        int payment = 300; 
        int numPayments = 0;  
   
        System.out.println("Initial balance: $" + balance); 

        while (balance >= payment) { 
            balance -= payment; 
            numPayments++;     
        } 

        System.out.println("You can pay off the loan in " +
                numPayments + " payments of $" + payment); 

        if (balance > 0) { 
            System.out.println("and one payment of $" + balance); 
        } 
    } 
}
