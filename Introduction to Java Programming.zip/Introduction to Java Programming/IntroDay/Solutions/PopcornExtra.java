public class PopcornExtra { 

    public static void main(String[] args) { 

        int numPeople = Integer.parseInt(args[0]); 

        if (numPeople > 0) { 

            // variables to count required number of tubs of each type 
            int large = 0;
            int grande = 0; 
            int jumbo = 0; 

            double largePrice = 5.75;
            double grandePrice = 7.95;
            double jumboPrice = 9.95;
            double totalPrice = 0; 

            System.out.println("Number of people: " + numPeople); 
            System.out.println();  // print blank line

            // keep ordering jumbos as long as you have 3 or more people
            while (numPeople >= 3) { 

                jumbo++; 
                totalPrice += jumboPrice;
                numPeople -= 3; 
 
            }                  

            if (numPeople == 1) { 

               large++; 
               totalPrice += largePrice;
        
            } else if (numPeople == 2) {  

               grande++; 
               totalPrice += grandePrice;

            }                    

            System.out.println("Total large tubs: " + large); 
            System.out.println("Total grande tubs: " + grande); 
            System.out.println("Total jumbo tubs: " + jumbo); 
            
            System.out.println(); // print blank line

            System.out.println("Total price: $" + totalPrice); 

        } else { 

            System.out.println("Error: You don't need popcorn!"); 

        }   
    }
}
