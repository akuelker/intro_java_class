
public class PassFail {
public static void main(String[] args)
{
int examScore = Integer.parseInt(arg[0]);

if(examScore >= 60)
{
	System.out.println("You passed");


}
else
	System.out.println("Score: " + examScore);
System.out.println("You failed.");
}
}