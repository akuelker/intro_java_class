public class PrePost { 

    public static void main(String[] args) { 

        // declares variable to increment 
        int aNum = 0;     

        // declares variables to test prefix and postfix operators
        int prefix;       
        int postfix;      

        // increments aNum to 1 and displays value 
        ++aNum;           
        System.out.println("aNum is now " + aNum); 

        // increments aNum to 2 and displays value 
        aNum++;           
        System.out.println("aNum is now " + aNum); 

        // increments aNum to 3 then assigns aNum to prefix 
        prefix = ++aNum;                           

        System.out.println("aNum is now " + aNum); 
        System.out.println("prefix is " + prefix); 

        // assigns aNum to postfix then increments aNum to 4
        postfix = aNum++; 

        System.out.println("postfix is " + postfix);   
        System.out.println("aNum is now " + aNum); 
    } 
}
