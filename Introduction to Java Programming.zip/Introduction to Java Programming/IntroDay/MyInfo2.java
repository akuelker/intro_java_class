
public class MyInfo
{

	public static void main(String[] args)
	{
		String myFirstname = "Amanda";
		String myLastname = "Kuelker";
		//to use double quote must use \ as an escape character (\t is tab, \n is new line)
		System.out.println(myFirstname + " " + myLastname + "\n906 Shandra Dr. \nBallwin, MO 63021");
		// displays name and address

	}

}
