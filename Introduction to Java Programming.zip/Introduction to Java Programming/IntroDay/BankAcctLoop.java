public class BankAcctLoop {

    public static void main(String[] args) {

        double acctBalance = 650.5;
        double monthSalary = 2345.67; 
        int rent = 700; 

        acctBalance += monthSalary; 
        acctBalance -= rent; 

        System.out.println("Ending balance: $" + acctBalance); 
    }
}
