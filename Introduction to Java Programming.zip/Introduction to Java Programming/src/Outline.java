
public class Outline
{

	public static void main(String[] args) 
	{
		int num = 0;
		
		for (int i = 1; i <= 3; i++)
			{
				num = i;
				System.out.println(num + ".");
					for (int j = 1; j <=3; j++)
					{
						num = j;
						System.out.println("	" + num + ")");
					}
					
				
				
			}

	}

}
