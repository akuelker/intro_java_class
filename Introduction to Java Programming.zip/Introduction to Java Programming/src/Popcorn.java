
public class Popcorn 
{

	public static void main(String[] args) 
	{
		int people = Integer.parseInt(args[0]);
		String size = "";
		double price = 0;
		if (people <= 0)
			{
				System.out.println("Enter valid number of people");
			}
		else if (people == 1)
			{
				size = "Large";
				price = 5.75;
			}
		else if	(people ==2)
			{
				size = "Grande";
				price = 7.95;
			}
		else if (people >= 3)
			{
				size = "Jumbo";
				price = 9.95;
			}
		System.out.println("Your popcorn order is " + size + " and the price is $" + price + ".");
	}

}
