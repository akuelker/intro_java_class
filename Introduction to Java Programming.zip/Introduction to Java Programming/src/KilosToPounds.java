
public class KilosToPounds
{

	public static void main(String[] args)
	{
		double kilos = 0;
		double pounds = 0;
	
		
		for(int i = 2; i <= 20; i += 2)
		{
			kilos = i;
			pounds = (i * 2.2);
			System.out.println(kilos + " kilos is " + pounds + " pounds");
		}

	}

}
