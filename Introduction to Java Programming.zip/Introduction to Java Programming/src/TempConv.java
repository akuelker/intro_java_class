
public class TempConv
{


	public static void main(String[] args)
{
		int fahTemp = 108;
		double celsConv = 5.0/9.0 * (fahTemp - 32);
	
	
	System.out.println("Celsius: " + celsConv + "\nFahrenheit: " + fahTemp);

	}

}
