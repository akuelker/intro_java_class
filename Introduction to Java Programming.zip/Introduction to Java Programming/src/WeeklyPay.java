
public class WeeklyPay
{

	public static void main(String[] args)
	{
		int hoursWorked = Integer.parseInt(args[0]);
		final int payRate = 30;
		char status = 'N';
		double weeklyPay;
		
		if (hoursWorked > 40 && status == 'N')
			{
			weeklyPay = (payRate * 40) + ((hoursWorked - 40) * (payRate * 1.5));
	 		}
		
		else 
			{
				weeklyPay = payRate * hoursWorked;
			}
		System.out.println("Classification: " + status);
		System.out.println("Weekly hours " + hoursWorked);
		System.out.println("Weekly pay: $" + weeklyPay);
		
		
		}
	

	}


