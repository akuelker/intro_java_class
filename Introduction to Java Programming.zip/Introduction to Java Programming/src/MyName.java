import com.sun.jndi.url.iiopname.iiopnameURLContextFactory;


public class MyName 
{


	public static void main(String[] args)
	{
	String myName = "Amanda Kuelker";
	
	for(int i = 1; i <= 5; i++)
		{
			System.out.println(myName);
		}
	
	}

}
