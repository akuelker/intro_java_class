
public class PassFail {
	public static void main(String[] args) 
	{
		int examScore = Integer.parseInt(args[0]);
		boolean passingGrade = (examScore >= 60);
		
		if(passingGrade)
		{
			System.out.println("Passing Score: " + examScore);
			System.out.println("You Passed");
		}
		else 
		{
			System.out.println("Failing Score: " + examScore);
			System.out.println("You Failed");
		}
			
	}
}
