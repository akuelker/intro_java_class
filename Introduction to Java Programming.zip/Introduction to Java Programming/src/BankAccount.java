
public class BankAccount 
{

	public static void main(String[] args)
	{
		
		double acctBalance = 650.5;
		
		double monthlySalary = 345.67;
		double partTimeSal = 250;
		double payback = 150;
		final int RENT = 700; //sets this as a constant and cannot be changed programmatically. CAPITALS to remind you
		//int numTrans = 0;
		
		//yellow means variable declared but not initialized. Remember case sensitive. 
		// can assign variables at declaration
		
		
		for(int i = 1; i <= 12; i++)
			{
			acctBalance += monthlySalary;
			//same as acctBalance = acctBalance + monthlySalary
			/*
			if(i % 2 ==0)// even. divide something by 2 and no remainder, even
				{
					continue; //goes back to beginning of loop
				}
				*/
			acctBalance = acctBalance - RENT;
			//numTrans++; //autoincrementer - automatically add one
			//can also do ++numTrans - doesn't matter if before or after in this case
			
				for (int j = 1; j <=2; j++) //to include biweekly
					{
						acctBalance += partTimeSal;
						acctBalance -= payback;
					}
			if (acctBalance < 0)
				{
					System.out.println("You went broke in month " + i);
					break;
				}
			}
			
		//System.out.println("Account Balance: $" + acctBalance);
		//System.out.println("Number of transactions: " + numTrans);
		System.out.println("Ending Balance: $" + acctBalance);

	}

}
