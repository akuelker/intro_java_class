
public class VacationDays 
{


	public static void main(String[] args) 
	{
		int Years = Integer.parseInt(args[0]);
		int VacationDays = 0;
		
		
		if (Years <= 1)
			{
				VacationDays = 5;
			}
			else if (Years <= 5)
			{
				VacationDays = 10;
			}
			else if (Years <= 10)
			{
				VacationDays = 15;
			}
			else 
			{
				VacationDays = 20;
			}
		
		System.out.println("You have " + VacationDays + " vacation days.");

			
		}
}
			
	


