public class Millionaire { 

    public static void main(String[] args) { 

        double totalSavings = 0; 
        int goal = 1000000;
        int annDeposit = 1000; 
        double annRate = .1; 
        int numYears = 0;    
         System.out.println("How many years will it take you to save $"
                + goal + "?");
     
        System.out.println("Initial savings: " + totalSavings);
        System.out.println("Yearly additions: " + annDeposit);
        System.out.println("Annual interest rate: " + annRate);

        while (totalSavings <= goal) {

            totalSavings += annDeposit;
            totalSavings *= (1 + annRate); 
            numYears++; 

            System.out.println("Total savings after year " + numYears + 
                    ": $" + totalSavings); 
        } 
      
        System.out.println("It will take you " + numYears + 
                " years to save $" + goal); 
    } 
}
