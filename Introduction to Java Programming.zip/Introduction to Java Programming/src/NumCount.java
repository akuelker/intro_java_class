
public class NumCount
{

	public static void main(String[] args) 
	{
		int num = 2;
		int numTimes = 0;
		
		while (num <= 32)
			{
				num += 2;
				numTimes++;
				
			}
		System.out.println("The loop took " + numTimes + " iterations.");	
			
			
		

	}

}
