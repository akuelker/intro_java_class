
public class SquareRoot
{

	public static void main(String[] args)
	{
		double num = Double.parseDouble(args [0]);
		
		double sqrtNum = Math.sqrt(num);
		
		System.out.println("The square root of " + num + " is "  + sqrtNum);
		}

}
