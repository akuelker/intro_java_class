
public class MemDues 
{


	public static void main(String[] args) 
	{
	int memCode = Integer.parseInt(args[0]);
	String descrip = "GENERAL";
	double dues = 24.95;
	
	if (memCode >= 1 && memCode <= 3)
		{
		
		switch(memCode)
		{
			case 1: 
				descrip = "CHILD";
				dues = 10.95;
						break;
			case 2: 
				descrip = "STUDENT";
				dues = 15.95;
					break;
			case 3: 
				descrip = "SENIOR";
				dues = 19.95;
						break;	
			default: 
				descrip = "GENERAL";
				dues = 24.95;
				break;
		}
	System.out.println("Mem code: " + memCode + "\nDescription: " + descrip + "\nDues: $" + dues);
		}
	else {
		System.out.println("Bad Code");
	}
	}
}
