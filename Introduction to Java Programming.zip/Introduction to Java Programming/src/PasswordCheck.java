
public class PasswordCheck 
{


	public static void main(String[] args)
	{
		String login = args[0];
		String password = "java";
		
		if (password.equalsIgnoreCase(login))
		System.out.println("come on in!");
		else
			System.out.println("The real password has " + password.length() + " characters.");
			System.out.println("It starts with " + password.charAt(0));
			System.out.println("It ends with " + password.charAt(password.length() - 1));
			System.out.println("Middle two characters are " + password.substring(1,3));
			//substring - give me what is between where I start and end (1 and 3 is 1, 2)
			// ending - beginning
			

	}

}
