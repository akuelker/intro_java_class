
public class Rounding 
{

	public static void main(String[] args)
	{
		double num = 32.94567;
		
		System.out.println("Normal rounding: " + Math.round(num));
		System.out.println("Ceiling rounding: " + Math.ceil(num));
		System.out.println("Floor rounding: " + Math.floor(num));

	}

}
