
public class Raise 
{


	public static void main(String[] args)
	{
		int perfScore = Integer.parseInt(args [0]);
		double raise;
		
		switch (perfScore)
			{
			case 1:
				raise = 0.05;
				break;
			case 2:
				raise = 0.03;
				break;
			case 3:
				raise = 0.01;
				break;
			default:
				raise = 0;
				break;
			}
		
		double newSalary = 30000 * (1 + raise);
		
		System.out.println("Your new salary is $" + newSalary);
		
	}

}
