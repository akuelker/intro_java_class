
public class MultiplicationTable
{

	public static void main(String[] args)
	{
	 int num = Integer.parseInt(args[0]);
	 int mult = 0;
	 
	 for(int i = 1; i <= 12; i++)
		 {
			 mult = num * i;
			 System.out.println(num + " x " + i + " = " + mult);
			 
		 }

	}

}
