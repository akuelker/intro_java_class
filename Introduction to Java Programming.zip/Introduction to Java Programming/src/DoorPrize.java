
public class DoorPrize
{

	public static void main(String[] args)
	{
		int winner = (int) (Math.random() * 50 ) + 1;
		
		System.out.println("The winner is " + winner);

	}

}
