
public class DiscountPrice 
{

	public static void main(String[] args) 
	{
		int originalPrice = Integer.parseInt(args[0]);
		double discPercent = 0.05;
		double discAmount = originalPrice * discPercent;
		double newPrice = originalPrice - discAmount;
		
		
		System.out.println("Discounted price = $" + newPrice);
		System.out.println("Rounded discounted price = $" + Math.round(newPrice));
		System.out.println("Rounded up discounted price = $" + Math.ceil(newPrice));

	}

}
