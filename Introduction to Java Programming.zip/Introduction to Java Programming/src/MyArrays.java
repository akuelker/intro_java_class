import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;


public class MyArrays
{

	public static void main(String[] args) 
	{
		int [] myArray = new int [5]; //empty array
		int [] myArray2 = {34,56,78,71,38,54,72,62,18}; //value list
		
/*for (int i=0; i < myArray2.length; i++)
	{
		System.out.println(myArray2[i]);
	}*/
		
	for (int i : myArray2) //type "foreach" and this populates
		{
			System.out.println(i);
		}	
	}

}
