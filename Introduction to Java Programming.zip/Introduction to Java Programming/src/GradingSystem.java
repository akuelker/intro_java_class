
public class GradingSystem 
{

	public static void main(String[] args) 
	{
		int examScore = Integer.parseInt(args[0]);
		char letterGrade; 
		char signGrade = ' ';
		
		if (examScore >=0 && examScore <= 100)
			{
			
					if (examScore >= 90)
						letterGrade = 'A';
					else if (examScore >=80)
						letterGrade = 'B';
					else if (examScore >=70)
						letterGrade = 'C';
					else if (examScore >=60)
						letterGrade = 'D';
					else 
						letterGrade = 'F';
					
					
					if ((examScore % 10 >= 7 && examScore % 10 <=9)|| 
							examScore == 100)
					{
					signGrade = '+';
					}
			
			else if (examScore % 10 >= 0 && examScore % 10 <= 2)
					{
						signGrade = '-';
					}
		
				System.out.println("Score: " + examScore);
				System.out.println("Grade: " + letterGrade +signGrade);
				
			}
		else
			{
				System.out.println("Score must be between 0 and 100");
			}
		
	}

}


