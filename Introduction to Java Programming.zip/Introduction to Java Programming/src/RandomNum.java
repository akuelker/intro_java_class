
public class RandomNum 
{

	public static void main(String[] args)
	{
		int die1 = (int) (Math.random() * 6 ) + 1;
		int die2 = (int) (Math.random() * 6 ) + 1;
		//int is casting from double to integer, getting rid of decimals
		
		System.out.println("Roll: " + die1 + " & " + die2);

	}

}
