
public class PriceCalc
{


	public static void main(String[] args)
	{
		final double TaxRate = .075;
		double Price = 10.00;
		double Tax = Price * TaxRate;
		double SalePrice = Price * 1 + Tax;
		
		
		System.out.println("Price: $" + Price + "\nTax: $" + Tax + "\nTotal Price: $" + SalePrice);

	}

}
