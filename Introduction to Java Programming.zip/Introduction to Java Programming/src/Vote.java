
public class Vote
{

	public static void main(String[] args)
	{
	int Age = Integer.parseInt(args[0]);
	
	if (Age >= 18)
	{
		System.out.println("You can vote!");
	}
		
		else
		{
			System.out.println("You can vote in " + (18 - Age) + " years.");
			
		}
		
	

	}

}
