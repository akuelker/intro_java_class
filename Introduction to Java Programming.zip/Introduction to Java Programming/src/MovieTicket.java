
public class MovieTicket
{

	public static void main(String[] args)
	{
		int Age = Integer.parseInt(args[0]);
		double TicketPrice = 0;
		String movieCode = args[1];
		
		
		if (movieCode.equals("A") ||Age >= 60 || Age <= 12)
		{
			TicketPrice = 5.50;
		}
		else 
		{
			TicketPrice = 7.50;
		}
		System.out.println("Your ticket price is $" + TicketPrice + ".");
	}

}
