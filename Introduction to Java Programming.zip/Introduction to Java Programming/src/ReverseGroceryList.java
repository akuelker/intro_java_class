import java.util.Arrays;


public class ReverseGroceryList
{


	public static void main(String[] args)
	{	Arrays.sort(args);
	for (int i = args.length-1; i >=0; i--)
		
		
	{
		System.out.println(args[i]);
	}

	

	}

}
