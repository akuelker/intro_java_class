
public class GroceryBudget
{

	public static void main(String[] args) 
	{
		int budget = 200;
		double total = 0;
		
		for (int i = 0; i < args.length; i++)
			{
				total += Double.parseDouble(args[i]);
			}

		System.out.println("You've spent $" + total + " this month.");
		
		if (budget >= total)
		{
			System.out.println("Good job! You're on budget.");
		}
		else {
			System.out.println("You've went over budget by $" + (total-budget));
		}
	}

}
