
public class NameGame 
{

	public static void main(String[] args)
	{
		String fullName = args[0].toUpperCase();
		
		String first = fullName.substring(0, fullName.indexOf(' '));
		String last = fullName.substring(fullName.lastIndexOf(' ')+ 1);
		//backwards to space and then adding 1 to find the first letter
		//need double quotes around name in arguments

		System.out.println(fullName);
		System.out.println(first);
		System.out.println(last);
	}

}
