
public class Neighbor
{

	public static void main(String[] args) 
	{
	String myName = "Amanda";
	String neighbor = args[0];
	int lengthDiff;
	
	if (myName.compareToIgnoreCase(neighbor) < 0)
		{
			System.out.println("My name preceeds yours.");
		}
	else if (myName.compareToIgnoreCase(neighbor) > 0)
		{
			
			System.out.println("Your name preceeds mine.");
		}
	
	else
		{
			System.out.println("Our names are the same.");
		}
	
	if (myName.length() > neighbor.length())
		{
			lengthDiff = myName.length () - neighbor.length() ;
			System.out.println(myName + " is " + lengthDiff + " characters longer than " + neighbor);
		}
	else if (myName.length() < neighbor.length())
		{
		lengthDiff = neighbor.length() - myName.length ();
		System.out.println(neighbor + " is " + lengthDiff + " characters longer than " + myName);
		}
	else 
	{
		System.out.println(myName + " and " + neighbor + "are the same length");
	}

	}

}
