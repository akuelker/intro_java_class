
public class MyInfo
{

	public static void main(String[] args)
	{
		String myName = args[0] + " " + args[1];
		//to use double quote must use \ as an escape character (\t is tab, \n is new line)
		System.out.println(myName + "\n906 Shandra Dr. \nBallwin, MO 63021");
		// displays name and address

	}

}
