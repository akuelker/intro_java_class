
public class Recall
{

	public static void main(String[] args)
	{
		String custNum = args[0];
		String [] recallModels = {"X100","X770","Y111","Z440","Z949","A214"}; 
		
		for(int i = 0; i < recallModels.length; i++)
		{
			if (custNum.equals(recallModels[i]))
				{
					System.out.println("This has been recalled.");
				
				
				}
			
			else 
				{
					System.out.println("Your car is safe!");
				}
		break; //otherwise it prints 5 times.		
		}

	}

}
