
public class Payoff 
{

	public static void main(String[] args)
	{
		double bal = Double.parseDouble(args[0]);
		double payment = Double.parseDouble(args[1]);
		int numPayments = 0; //counter
		
		while (bal >= payment) //what I owe is greater than what I'm going to pay keep looping
		{
			bal -= payment;
			numPayments++; //adds one to number of payments
			System.out.println("New Balance after payment " + numPayments + ": $" + bal);
			
		}
		
		

	}

}
