import java.util.*; //import at top if anything but java.lang
public class CMDLine
{


	public static void main(String[] args) 
	{
		Arrays.sort(args); //sorts alphabetically
		for (String strName : args)

		{
			System.out.println(strName);	
		}


	}

}
