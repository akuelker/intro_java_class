
public class Baseball
{

	public static void main(String[] args) 
	{
	int hit = Integer.parseInt(args [0]);
	String hitType;
	
	switch(hit)
		{
			case 1:
				hitType = "Single";
			break;
			case 2:
				hitType = "Double";
			break;
			case 3:
				hitType = "Triple";
			break;
			case 4:
				hitType = "Home run";
			break;
		default:
			hitType = "You're out!";
			break;
		}
	System.out.println(hitType);
	}

}
