
public class MidThreeLetters
{

	public static void main(String[] args) 
	{
		String phrase = args[0];
		
		if (phrase.length() >= 3)
		{
			if (phrase.length()  % 2 == 0)
			{
				String midTwoString = phrase.substring(phrase.length() /2-1, phrase.length()/ 2+1);
				System.out.println(midTwoString.toUpperCase());
				
			}
			else 
			{
				String midThreeString = phrase.substring(phrase.length()/2-1, phrase.length()/2+2);
				System.out.println(midThreeString.toUpperCase());
			
			}
		}
			else 
			{
				System.out.println("Error! Longer phrase.");
			}
		
		
		
		

	}

}
