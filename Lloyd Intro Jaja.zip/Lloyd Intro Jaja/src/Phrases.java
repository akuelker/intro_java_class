
public class Phrases {

	public static void main(String[] args) {
		String phrase = "FREDDYG";
		
		
		System.out.println("Phrase: " + phrase.toUpperCase());
		
		if(phrase.length() % 2 == 0) // even
		{
			String middle2 = 
			 phrase.substring((phrase.length()/2) -1,(phrase.length()/2) + 1);
			System.out.println("Middle 2: " + middle2.toUpperCase());
		}
		else // odd
		{
			String middle3 = 
					 phrase.substring((phrase.length()/2) -1,(phrase.length()/2) + 2 );
					System.out.println("Middle 3: " + middle3.toUpperCase());
		}

	}

}
