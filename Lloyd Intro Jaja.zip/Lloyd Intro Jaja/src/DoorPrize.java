
public class DoorPrize {

	public static void main(String[] args) {
		int winner = (int) (Math.random() * 50) + 1;
		System.out.println("And the winner is..." + winner);
	}

}
