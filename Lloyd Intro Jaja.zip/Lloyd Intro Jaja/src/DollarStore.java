
public class DollarStore {

	public static void main(String[] args) {
		double price = Double.parseDouble(args[0]);
		double discPrice = price * .95;
		
		int roundedDiscPrice = (int) Math.round(discPrice);
		int cheatersPrice = (int) Math.ceil(discPrice);
		
		System.out.println("Price: $" + price);
		System.out.println("Discounted Price: $" + discPrice);
		System.out.println("Rounded Price: $" + roundedDiscPrice);
		System.out.println("Cheaters Price: $" + cheatersPrice);
		
		
		
		

	}

}
