
public class Recall {

	public static void main(String[] args) {
		String myModel = args[0];
		String[] recallList = {"X770", "Y111","Z949", "Z440", "A214"};
		
		for (String recalledModel : recallList) {
			if (myModel.equals(recalledModel))
			{
				System.out.println(myModel + " has been recalled");
				System.exit(0); // end program
			}
		}
		System.out.println(myModel + " is not on the recall list");

	}

}
