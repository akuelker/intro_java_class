
public class WeeklyPay {

	public static void main(String[] args) {
		String jobClass = args[0].toUpperCase();
		int hours = Integer.parseInt(args[1]);
		double weeklyPay = 0;
		double rate = 10;
		double ot = 0;
		
		if (jobClass.equals("EXEMPT"))
			weeklyPay = (40 * rate);
		else
		{
			if (hours > 40)
			{
				weeklyPay = (40 * rate);
				ot = (hours - 40) * rate * 1.5;
			}
			else 
				weeklyPay = (hours * rate);		
		}
		
		System.out.println("Class: " + jobClass);
		System.out.println("Hours: " + hours);
		System.out.println("Hourly rate: $" + rate);
		System.out.println("Regular Pay: $" + weeklyPay);
		System.out.println("Overtime: $" + ot);
		

	}

}
