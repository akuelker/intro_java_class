
public class MyInfo 
{
	
	public static void main(String[] args) 
	{
		String myName = args[0] + " " + args[1];
		
		System.out.println(myName); //
		System.out.println("111 Pioneer Ave.");
		System.out.println("Kirkwood, MO 63122");
	
	}
}
