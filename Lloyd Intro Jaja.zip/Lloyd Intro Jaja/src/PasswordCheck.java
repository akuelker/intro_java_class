
public class PasswordCheck {

	public static void main(String[] args) {
		String login = args[0].toLowerCase();
		String password = "java";
		
		if (password.equalsIgnoreCase(login))
			System.out.println("come on in!");
		else 
		{
			
			System.out.println("The real password has " + 
					password.length() + " characters.");
			System.out.println("It starts with a " + 
					password.charAt(0));
			System.out.println("It end with an " + 
					password.charAt(password.length() -1));
			System.out.println("Middle two characters are " + 
					password.substring(1,3));
			
		}
		

	}

}
