import java.util.Arrays;

public class Grocery {

	public static void main(String[] args) {
		Arrays.sort(args);
		
		for (String item : args) 
		{
			System.out.println(item);
		}
		
		System.out.println("****** Reverse Order *************");
		
		for (int i = args.length -1; i >= 0; i--)
		{
			System.out.println(args[i]);
		}

	}

}
