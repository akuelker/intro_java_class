
public class Budget {

	public static void main(String[] args) {
		 double[] lineItems = new double[args.length];
		 double total = 0;
		 
		 for (int i = 0; i < args.length; i++) 
		 { 
			 lineItems[i] = Double.parseDouble(args[i]); 
			 System.out.println("Item " + (i+1) + ": $" + lineItems[i]);
			 total += lineItems[i];
         } 
		 
		 System.out.println("Total: $" + total);
		 
		 if (total > 200)
		 {
			 System.out.println("You have overspent by $" + (total-200));
		 }
		 
	}

}
