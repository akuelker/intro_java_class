
public class MinMAx {

	public static void main(String[] args) {
		int x  = 10; 
		int y = 25;
		
		System.out.println(Math.min(x, y) +  " is the smaller number.");
		System.out.println(Math.max(x, y) +  " is the larger number.");
	}

}
