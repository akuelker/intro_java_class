public class MemDues {

	public static void main(String[] args) {
		int memCode = Integer.parseInt(args[0]);
		String descrip = "GENERAL";
		double dues = 24.95;

		if (memCode >= 1 && memCode <= 13) 
		{
			switch (memCode) 
			{
				case 1:
				case 11:
					descrip = "CHILD";
					dues = 10.95;
					break;
				case 2:
				case 12:
					descrip = "STUDENT";
					dues = 15.95;
					break;
				case 3:
				case 13:
					descrip = "SENIOR";
					dues = 19.95;
					break;
				default:
					descrip = "GENERAL";
					dues = 24.95;
					break;
			}

			System.out.println("Mem Code: " + memCode);
			System.out.println("Description: " + descrip);
			System.out.println("Dues: $" + dues);
		} else
			System.out.println("Bad Code");
	}
}
