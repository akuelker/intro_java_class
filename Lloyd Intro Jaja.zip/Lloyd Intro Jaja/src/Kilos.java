
public class Kilos {

	public static void main(String[] args) {
		int kilos = 0;
		double lbs = 0;
		
		for (kilos = 2; kilos <=20; kilos +=2)
		{
			lbs = kilos * 2.2;
			System.out.println(kilos +" kilos converts to " + lbs + " pounds");
		}

	}

}
