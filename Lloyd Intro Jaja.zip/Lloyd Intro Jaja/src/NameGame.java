
public class NameGame {

	public static void main(String[] args) {
		String fullName = args[0].toUpperCase();
		
		String first = fullName.substring(0, fullName.indexOf(' '));
		String last = fullName.substring(fullName.lastIndexOf(' ') + 1);
	
		System.out.println(fullName);
		System.out.println(first);
		System.out.println(last);

	}

}
