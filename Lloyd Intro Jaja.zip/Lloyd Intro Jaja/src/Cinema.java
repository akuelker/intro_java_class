
public class Cinema {

	public static void main(String[] args) {
		String movieType = args[0];
		int age = Integer.parseInt(args[1]);
		double cost = 0;
		
		if ((movieType.equals("A")) || 
									(age <= 12) ||
											(age >= 60))
			cost = 5.50;
		else 
			cost = 7.50;

		System.out.println("Cost: $" + cost);
		
	}

}
