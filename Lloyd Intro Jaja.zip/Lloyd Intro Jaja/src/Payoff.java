
public class Payoff {

	public static void main(String[] args) {
		double bal = Double.parseDouble(args[0]);
		double payment = Double.parseDouble(args[1]);
		int numPayments = 0;
		
		while (bal >= payment)
		{
			bal -= payment;
			numPayments++;
			System.out.println("New Balance after payment " + 
					numPayments + ": $" + bal);
		}	
	}

}
