
public class Rounding {

	public static void main(String[] args) {
		double num = 32.99999;
		
		System.out.println("Normal rounding: " + Math.round(num));
		System.out.println("Round Up: " + Math.ceil(num));
		System.out.println("Round Down: " + Math.floor(num));

	}

}
