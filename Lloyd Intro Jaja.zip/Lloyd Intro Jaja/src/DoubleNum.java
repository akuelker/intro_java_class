
public class DoubleNum {

	public static void main(String[] args) {
		int num =1;
		int count = 0;
		
		while (num < 32)
		{
			num *= 2;
			count++;
			System.out.println(num);
		}
		
		System.out.println("It will take " +count + " interations.");

	}

}
