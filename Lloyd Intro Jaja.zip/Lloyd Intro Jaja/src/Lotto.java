import java.util.*; 

public class Lotto { 

    public static void main(String[] args) { 

        int[] yourPicks = new int[args.length]; 

        int[] correctNums = new int[3]; 

        // test for correct number of arguments
        if (args.length == correctNums.length) { 

            // transfer args array into an integer array
            for (int i = 0; i < args.length; i++) { 
                yourPicks[i] = Integer.parseInt(args[i]); 
            } 

            // generate three random integers and store in int array
            for (int i = 0; i < correctNums.length; i++) { 
                correctNums[i] = (int)(Math.random() * 10);        
            } 

            // sort both integer arrays 
            Arrays.sort(correctNums); 
            Arrays.sort(yourPicks); 

            System.out.println("Correct nums\tYou picked");

            // print correct numbers and user picks side-by-side      
            for (int i = 0; i < correctNums.length; i++) { 
                System.out.print(correctNums[i]); 
                System.out.println("\t\t" + yourPicks[i]); 
            }          

            // checks to see if arrays are equal
            if (Arrays.equals(yourPicks, correctNums)) { 
                System.out.println("You guessed correctly."); 
            } else { 
                System.out.println("Try again."); 
            } 

        } else { 

            // print this message if user entered wrong # of args
            System.out.println("You must pick " + correctNums.length 
                    + " numbers."); 
        } 
    } 
}

