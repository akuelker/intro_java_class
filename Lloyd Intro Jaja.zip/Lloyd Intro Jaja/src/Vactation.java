
public class Vactation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int age = Integer.parseInt(args[0]);
		
		
	}

}
