
public class Popcorn {
	public static void main(String[] args) {
		int people = Integer.parseInt(args[0]);
		int jumbo = 0;
		int grande = 0;
		int large = 0;
		double total = 0;
				
		
		if (people == 0)
			System.out.println("Invalid");
		else {
			if(people >= 3)
			{
				jumbo = people / 3;
				people = people % 3;
			}
			if(people >= 2)
			{
				grande = people / 2;
				people = people % 2;
			}
			if(people == 1)
				large++;
		}
		
		total = (jumbo * 9.95) +  (grande * 7.95)  +  (large * 5.75) ;
		
		System.out.println("People: " + people);
		System.out.println("Large: " + large);
		System.out.println("Grande: " + grande);
		System.out.println("Jumbo: " + jumbo);
		System.out.println("Total: $" + total);
	}

}
