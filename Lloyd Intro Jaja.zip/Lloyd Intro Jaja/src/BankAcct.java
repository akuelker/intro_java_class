
public class BankAcct 
{
	public static void main(String[] args) 
	{
		double acctBalance = 650.5;
		double monthSalary = 345.67;
		double partTimeSal = 250;
		double payback = 150;
		final int RENT = 700;

		for(int i = 1; i<= 12; i++)
		{
			acctBalance += monthSalary;
			
			/*
				if (i % 2 == 0) // even
				{
					continue;
				}
			*/
			
			acctBalance -= RENT;
			
			for (int j= 1; j<=2; j++)
			{
				acctBalance += partTimeSal;
				acctBalance -= payback;
			}
			
			if (acctBalance <0)
			{
				System.out.println("You went broke in month " + i);
				break;
			}
		}
	
		System.out.println("Ending Balance: $" + acctBalance);
	
		
	}
}
