
public class MyArrays {

	public static void main(String[] args) {
		int[] myArray = new int[5]; // empty array
		int[] myArray2 = {38,56,78,71,34,55,77,99,100}; // value list
		
		/*for (int i=0; i < myArray2.length; i++)
		{
			System.out.println(myArray2[i]);
		}*/
		
		for (int i : myArray2) 
		{
			System.out.println(i);
		}
		
		
		
	}

}
