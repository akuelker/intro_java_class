
public class Vacation {

	public static void main(String[] args) {

		int years = Integer.parseInt(args[0]);
		int days = 0;
		
		if (years >= 11) 
			days = 20;
		else if (years >= 6) 
			days = 15;
		else if (years >= 1) 
			days = 10;
		else  
			days = 5;
		
		System.out.println("For " + years + " year(s), you get " +
				days + " days of vacation.");	

	}

}
