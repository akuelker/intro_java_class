
public class Baseball {

	public static void main(String[] args) {
		int swing = Integer.parseInt(args[0]);
		String hit = "OUT";
		
		switch(swing)
		{
			case 1:
				hit = "Single";
				break;
			case 2:
				hit = "Double";
				break;
			case 3:
				hit = "Triple";
				break;
			case 4:
				hit = "Home Run";
				break;
			default:
				hit = "Out";
				break;
		}
		
		System.out.println(hit);

	}

}
