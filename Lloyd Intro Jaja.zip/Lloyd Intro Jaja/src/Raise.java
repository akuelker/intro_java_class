
public class Raise {

	public static void main(String[] args) {
		int score = Integer.parseInt(args[0]);
		double salary = 0;
		
		if (score >= 1 && score <=3)
		{
			switch(score){
			case 1:
				salary = 30000 * 1.05;
				break;
			case 2:
				salary = 30000 * 1.03;
				break;
			case 3:
				salary = 30000 * 1.01;
				break;
			}
			System.out.println("Score: " + score);
			System.out.println("New Salary: $" + salary);
		}	
		else
			System.out.println("Invalid score");
		
		
	}

}
