
public class PriceCalc {

	public static void main(String[] args) {
		double dblPrice = Double.parseDouble(args[0]);
		final double TAX_RATE = .075;
		double dblTaxes = 0;
		double dblSubTotal = 0;
		
		dblTaxes = dblPrice * TAX_RATE;
		dblSubTotal = dblPrice + dblTaxes;
		
		System.out.println("Price: $" + dblPrice);
		System.out.println("Taxes: $" + dblTaxes);
		System.out.println("Total: $" + dblSubTotal);
	}

}
