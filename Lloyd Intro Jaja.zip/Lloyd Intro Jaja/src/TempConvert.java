
public class TempConvert {

	public static void main(String[] args) {
		double dblFah = Double.parseDouble(args[0]);
		
		double dblCel = 5.0 / 9.0 * (dblFah -32);
				
		System.out.println(dblFah + " converts to " + dblCel);

	}

}
