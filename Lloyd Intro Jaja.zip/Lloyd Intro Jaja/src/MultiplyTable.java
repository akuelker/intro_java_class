
public class MultiplyTable {

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		
		for (int i = 1; i<=12; i++)
		{
			System.out.println(num + " X " + i + " = " + (num*i));
		}
	}

}
