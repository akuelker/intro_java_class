
public class CompareNames {

	public static void main(String[] args) {
		String myName = "Lloyd".toUpperCase();
		String neighbor = args[0].toUpperCase();
		
		System.out.println(myName);
		System.out.println(neighbor);
		
		if (myName.compareTo(neighbor) < 0)
			System.out.println("My name proceeds my neighbors name.");
		else if (myName.compareTo(neighbor) > 0)
			System.out.println("Neighbors name proceeds my name.");
		else if (myName.compareTo(neighbor) == 0)  
			System.out.println("Same names.");
		
		if(myName.length() > neighbor.length())
		{
			System.out.println("My name is " + 
						(myName.length() - neighbor.length()) + 
							" characters longer." );
		}
		else if(neighbor.length() > myName.length())
			{
				System.out.println("Neighbor's name is " + 
							(neighbor.length() - myName.length()) + 
								" characters longer." );
			}
	}

}
