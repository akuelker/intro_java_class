
public class RandomNum {

	public static void main(String[] args) {
		int die1 = (int) (Math.random() * 6) + 1;
		int die2 = (int) (Math.random() * 6) + 1;
		
		System.out.println("Roll: " + die1 + " & " + die2);
	}

}
